Note: The sound functionality requires an ambient.mp3 file.
You can add your own mp3 file to the resources/sounds directory and rename it to ambient.mp3.
If you don't add a sound file, the application will still work but without sound.
